## Color Images from Python Playground

This directory has the color versions of all images and illustrations in the printed book.
